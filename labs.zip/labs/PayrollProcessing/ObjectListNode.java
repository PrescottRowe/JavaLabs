/**
 *
 */
package payrolllab;

/**
 * Class sets up a Node Object to be used for holding data in the ObjectList.
 * @author prescott rowe 008771839
 */
public class ObjectListNode implements ObjectListNodeInterface, ObjectListInterface{
    
    private Object info;
    private ObjectListNode next;
    /**
     * Default constructor for node.
     */     
    public ObjectListNode() {
        info = null;
        next = null;
    }

    /**
     * One argument constructor.
     * @param o Object
     */
    public ObjectListNode (Object o) {
        info = o;
        next = null;
    }    
    
    /**
     * Two Argument constructor.
     * @param o Object
     * @param p ObjectListNode
     */
    public ObjectListNode (Object o, ObjectListNode p) {
        info = o;
        next = p;
    }       

    /**
     * Used to set the info field of the Node.
     * @param o Object
     */
    public void setInfo(Object o) {
        info = o;
    }    

    /**
     * Accessor method for info.
     * @return Object info
     */
    public Object getInfo() {
        return info;
    }

    /**
     * Mutator method for next field of Node.
     * @param p ObjectListNode
     */
    public void setNext(ObjectListNode p) {
        next = p;
    }

    /**
     * Accessor method for next field of Node
     * @return reference pointer to next node
     */
    public ObjectListNode getNext() {
        return next;
    }
}




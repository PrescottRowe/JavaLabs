/**
 *
 */
package payrolllab;

/**
 *
 * @author Prescott Rowe 008771839
 */
public interface Comparable {
    public int compareTo(Object o);  
}

/**
 *
 */
package payrolllab;

/**
 *
 * @author scott
 */
public interface ObjectListNodeInterface {
    
}

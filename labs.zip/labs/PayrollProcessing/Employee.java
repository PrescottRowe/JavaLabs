/**
 *
 */
package payrolllab;

/**
 * Creates fields for an employee Object.
 * @author Prescott Rowe 008771839
 */
public class Employee implements Comparable {
    private String firstName;
    private String lastName;
    private String gender;
    private String tenure;
    private String rate;
    private String salary;
    /**
     * Mutator method for firstName.
     * @return String firstName
     */
    public String getFirstName(){
        return firstName;
    }
    /**
     * Mutator method for lastName.
     * @return String lastName
     */
    public String getLastName(){
        return lastName;
    }
    /**
     * Mutator method for gender.
     * @return String gender
     */
    public String getGender(){
        return gender;
    }
    /**
     * Mutator method for tenure.
     * @return String tenure
     */
    public String getTenure(){
        return tenure;
    }
    /**
     * Mutator method for rate.
     * @return String rate
     */
    public String getRate(){
        return rate;
    }
    /**
     * Mutator method for salary.
     * @return String salary
     */
    public String getSalary(){
        return salary;
    }
    /**
     * Accessor method for firstName.
     * @param name String
     */
    public void setFirstName(String name){
        firstName=name;
    }
    /**
     * Accessor method for lastName
     * @param name String
     */
    public void setLastName(String name){
        lastName=name;
    }
    /**
     * Accessor method for gender.
     * @param gender String
     */
    public void setGender(String gender){
        this.gender=gender;
    }
    /**
     * Accessor method for tenure.
     * @param tenure String
     */
    public void setTenure(String tenure){
        this.tenure=tenure;
    }
    /**
     * Accessor method for rate.
     * @param rate String
     */
    public void setRate(String rate){
        this.rate=rate;
    }
    /**
     * Accessor method for salary.
     * @param salary String
     */
    public void setSalary(String salary){
        this.salary=salary;
    }
    /**
     * Compares two string names and returns an integer that should be used as a boolean.
     * @param o Object
     * @return boolean integer
     */
    @Override
    public int compareTo(Object o){
       Employee a=(Employee) o;
       return lastName.compareTo(a.getLastName());
    }
}

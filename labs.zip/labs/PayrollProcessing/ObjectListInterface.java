/**
 *
 */
package payrolllab;

/**
 *
 * @author scott
 */
public interface ObjectListInterface {
    
}

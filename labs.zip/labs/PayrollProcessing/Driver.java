/**
 *
 */
package payrolllab;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Program PayRollLab edits and maintains an employee database.
 * @author Prescott Rowe 008771839
 */
public class Driver {

    /**
     * Main Class for program, streams in payfile.txt and calls a flexible set of methods to edit the data from the file.
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException for file scanner
     */
    public static void main(String[] args) throws FileNotFoundException {
        PayRoll pay=new PayRoll();
        String[] buf;
        Scanner fileScan;
        fileScan = new Scanner(new File("payfile.txt"));
        // turns line stream into a split string array
        while(fileScan.hasNext()){
            String delims="[ ]+";
            String holdLine=fileScan.nextLine();
            buf=holdLine.split(delims);  
            pay.payList(buf);
        }
        //meathod calls to run the program
        pay.printList();
        pay.numberOfEmployees();
        pay.printWomen();
        pay.wellPayedWeeklys();
        pay.raise();
        pay.alphaSort();
        pay.hire();
        pay.fire();
        //exit
        pay.pw.close();
        System.exit(0);
    }
    
}

/**
 *
 */
package payrolllab;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 * Contains all the user defined methods to edit and maintain the payfile.txt data.
 * @author Prescott Rowe 008771839
 */
public class PayRoll{
    ObjectList list;
    ObjectList alphaList;
    ObjectListNode p;
    ObjectListNode q;
    PrintWriter pw;
    
    /**
     * Default constructor to set Object
     * 
     */
    public PayRoll() {
        try{
            this.q = new ObjectListNode();
            this.p = new ObjectListNode();
            this.alphaList = new ObjectList();
            this.list = new ObjectList();
            this.pw = new PrintWriter(new FileWriter("csis.txt"));
        } catch (IOException ex) {
            Logger.getLogger(PayRoll.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Takes a line from payfile.txt called buf and inserts the data into a 'person' Object.
     * @param buf String[]
     */
    public void payList(String[] buf){
        Employee person=new Employee();
        person.setFirstName(buf[0]);
        person.setLastName(buf[1]);
        person.setGender(buf[2]);
        person.setTenure(buf[3]);
        person.setRate(buf[4]);
        person.setSalary(buf[5]);        
        list.addLast(person);
    }
    /**
     * Overloadable method used to create a tabular format for prints.
     */
    public void format(){
        System.out.println("First Name"
                    +'\t'+"Last Name"
                    +'\t'+"Gender"
                    +'\t'+"Tenure"
                    +'\t'+"Rate"
                    +'\t'+"Salary");
        pw.println("First Name"
                    +'\t'+"Last Name"
                    +'\t'+"Gender"
                    +'\t'+"Tenure"
                    +'\t'+"Rate"
                    +'\t'+"Salary");
    }
    /**
     * Overloadable method used to create a tabular format for prints.
     * @param firstName String 
     */
    public void format(String firstName){
        System.out.println(firstName);
        pw.println(firstName);
    }
    /**
     * Overloadable method used to create a tabular format for prints.
     * @param firstName String
     * @param lastName String 
     */
    public void format(String firstName, String lastName){
        System.out.println(firstName
                    +'\t'+lastName);
        pw.println(firstName
                    +'\t'+lastName);
    }
    /**
     * Overloadable method used to create a tabular format for prints.
     * @param firstName String
     * @param lastName String 
     * @param salary String
     */
    public void format(String firstName,String lastName, String salary){
        System.out.println(firstName
                    +'\t'+lastName
                    +'\t'+salary);
        pw.println(firstName
                    +'\t'+lastName
                    +'\t'+salary);
    }
    /**
     * Prints out the linked list of employee Objects taken from payfile.txt.
     */
    public void printList(){
        p=list.getFirstNode();
        System.out.println("Payfile list:");
        pw.println("Payfile list:");
        format();
        while(p!=null){
            System.out.println(((Employee)p.getInfo()).getFirstName()
                    +"\t\t"+((Employee)p.getInfo()).getLastName()
                    +"\t\t"+((Employee)p.getInfo()).getGender()
                    +'\t'+((Employee)p.getInfo()).getTenure()
                    +'\t'+((Employee)p.getInfo()).getRate()
                    +'\t'+((Employee)p.getInfo()).getSalary());
            pw.println(((Employee)p.getInfo()).getFirstName()
                    +"\t\t"+((Employee)p.getInfo()).getLastName()
                    +"\t\t"+((Employee)p.getInfo()).getGender()
                    +'\t'+((Employee)p.getInfo()).getTenure()
                    +'\t'+((Employee)p.getInfo()).getRate()
                    +'\t'+((Employee)p.getInfo()).getSalary());
            p=p.getNext();
        }    
    }
    /**
     * Prints the number of employees within payfile.txt.
     */
    public void numberOfEmployees(){
        System.out.println("\nNumber of employees: "+list.size());
        pw.println("\nNumber of employees: "+list.size());
    }
    /**
     * Prints the first name of all women in payfile.txt.
     */
    public void printWomen(){
        System.out.println("\nNames of women employed:");
        pw.println("\nNames of women employed:");
        format("First Name");
        p=list.getFirstNode();
        while(p!=null){//if the gender field of employee p matches the string F then true and print
            if("F".equals(((Employee)p.getInfo()).getGender())){
                System.out.println(((Employee)p.getInfo()).getFirstName());
                pw.println(((Employee)p.getInfo()).getFirstName());
            }
            p=p.getNext();
        }    
    }
    /**
     * Prints the first name, last name, and salary of all weekly paid employees making more than 35k a year and whom have been loyal to the company for 5 or more years.
     */
    public void wellPayedWeeklys(){
        System.out.println("\nWeekly rate employees who make more than $35,000/y and have been loyal for 5 or more years:");
        pw.println("\nWeekly rate employees who make more than $35,000/y and have been loyal for 5 or more years:");
        format("First Name","Last Name","Salary");
        p=list.getFirstNode();
        while(p!=null){
            if("W".equals(((Employee)p.getInfo()).getRate())//if employee field rate equals W
                    &&Float.parseFloat(((Employee)p.getInfo()).getTenure())>=5//and more than 4 years of tenure
                    &&Float.parseFloat(((Employee)p.getInfo()).getSalary())>=673.08){//and high pay
                System.out.println(((Employee)p.getInfo()).getFirstName()//then print employee
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t"+((Employee)p.getInfo()).getSalary());
                pw.println(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t"+((Employee)p.getInfo()).getSalary());
            }
            p=p.getNext();
        }    
    }
    /**
     * Gives out needed raises to employees and prints their first name, last name, and new salary.
     */
    public void raise(){
        System.out.println("\nEmployees who got a raise:");
        pw.println("\nEmployees who got a raise:");
        format("First Name","Last Name","Salary");
        p=list.getFirstNode();
        while(p!=null){//sorry for the dense code here...
            if("H".equals(((Employee)p.getInfo()).getRate())//if hourly
                    &&Float.parseFloat(((Employee)p.getInfo()).getSalary())<=10){//and salary less than 10/h
                ((Employee)p.getInfo()).setSalary(String.valueOf(Float.parseFloat(((Employee)p.getInfo()).getSalary())+.75));//parse and give raise
                System.out.format(((Employee)p.getInfo()).getFirstName()//print
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t%4.2f\n",Float.parseFloat(((Employee)p.getInfo()).getSalary()));
                pw.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t%4.2f\n",Float.parseFloat(((Employee)p.getInfo()).getSalary()));
            }
            else if("W".equals(((Employee)p.getInfo()).getRate())//if weekly paid
                    &&Float.parseFloat(((Employee)p.getInfo()).getSalary())<=350){//and under 350 a week
                ((Employee)p.getInfo()).setSalary(String.valueOf(Float.parseFloat(((Employee)p.getInfo()).getSalary())+50));//parse and change there pay +50
                System.out.format(((Employee)p.getInfo()).getFirstName()//print
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t%4.2f\n",Float.parseFloat(((Employee)p.getInfo()).getSalary()));
                pw.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t%4.2f\n",Float.parseFloat(((Employee)p.getInfo()).getSalary()));
            }
            p=p.getNext();
        }
    }
    /**
     * Sorts original employee linked list into a new ordered linked list of employees;then prints the new list via first name, last name, salary.
     */
    public void alphaSort(){
        while(!list.isEmpty()){
            alphaList.insert(list.removeFirst());
        }
        p=alphaList.getFirstNode();//uses second list alpha list to easily sort old list
        System.out.println("\nEmployees sorted:");
        pw.println("\nEmployees sorted:");
        format("First Name","Last Name", "Salary");
        while(p!=null){
            System.out.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t%4.2f\n",Float.parseFloat(((Employee)p.getInfo()).getSalary()));
            pw.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()
                        +"\t\t%4.2f\n",Float.parseFloat(((Employee)p.getInfo()).getSalary()));
            p=p.getNext();
        }
    }
    /**
     * Streams and inserts employees from hirefile.txt into ordered employee list; Then prints new list via first name, last name.
     * 
    */
    public void hire(){
        try {           
            String[] buf;
            Scanner fileScan = new Scanner(new File("hirefile.txt"));
            while(fileScan.hasNext()){//streams in hire file into a pearson object to then get alpha inserted into new list
                String delims="[ ]+";
                String holdLine=fileScan.nextLine();
                buf=holdLine.split(delims);
                Employee person=new Employee();//new person
                //set person
                person.setFirstName(buf[0]);
                person.setLastName(buf[1]);
                person.setGender(buf[2]);
                person.setTenure(buf[3]);
                person.setRate(buf[4]);
                person.setSalary(buf[5]);
                alphaList.insert(person);//inserts person here
            }
            System.out.println("\nEmployee list after new hires:");
            pw.println("\nEmployee list after new hires:");
            format("First Name", "Last Name");
            p=alphaList.getFirstNode();
            while(p!=null){//print list
                System.out.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()+"\n");
                pw.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()+"\n");
                p=p.getNext();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PayRoll.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**
     * Streams from firefile.txt and deletes specified employee nodes from linked list; Then prints first name, last name.
     * 
     */
    public void fire(){
        try {
            String[] buf;
            Scanner fileScan = new Scanner(new File("firefile.txt"));
            //stream in firefile and if matching fields delete node
            while(fileScan.hasNext()){
                p=alphaList.getFirstNode();
                q=null;
                String delims="[ ]+";
                String holdLine=fileScan.nextLine();
                buf=holdLine.split(delims);
                while(p!=null){
                    if(((Employee)p.getInfo()).getLastName().equals(buf[1])//if buffed field matches an employee
                            &&((Employee)p.getInfo()).getFirstName().equals(buf[0])){
                        if(q == null){ //then remove (boundry case)
                            alphaList.removeFirst();
                        }
                        else{//then remove
                            alphaList.deleteAfter(q);
                        }
                    }
                    q=p;
                    p=p.getNext();           
                }
            }
            System.out.println("\nEmployee list after fires:");
            pw.println("\nEmployee list after fires:");
            format("First Name", "Last Name");
            p=alphaList.getFirstNode();
            while(p!=null){//print new list
                System.out.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()+"\n");
                pw.format(((Employee)p.getInfo()).getFirstName()
                        +"\t\t"+((Employee)p.getInfo()).getLastName()+"\n");
                p=p.getNext();
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(PayRoll.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}

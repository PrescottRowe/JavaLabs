
package reviewlab;
import java.io.*;
import java.util.Scanner;


/**
 * Converts, Formats, and Prints the conversion of a Decimal number to either a Binary or Hexadecimal number.
 * @author Prescott Rowe 008771839
 */
public class Decimal{
    final private PrintWriter pw;
    private int value;//input value
    private String numStrg;//String that holds conversion value
    /**
     * 
     * @param pw is a PrintWriter object used to create an output file stream to csis.txt
     */
    public Decimal(PrintWriter pw) {
        this.pw = pw;
    }
    /**
     * Invokes all off the methods to do a decimal to binary conversion.
     * Instantiates/clears numStrg to an empty value.
     */
    public void decToBin(){
        numStrg="";//Instantiates/clears
        inputDec();
        toBin();
        outBin();
    }
    /**
     * Invokes all off the methods to do a decimal to hexadecimal conversion.
     * Instantiates/clears numStrg to an empty value.
     */
    public void decToHex(){
        numStrg="";
        inputDec();
        toHex();
        outHex();
    }
    /**
     * Prints/echos user's option and ask for the user to input a dec number to be converted.
     * Then saves and prints/echos input.
     * 
     */
    private void inputDec(){
        System.out.print("Enter the Decimal number to be converted: ");
        pw.print("\nEnter the Decimal number to be converted: ");
        Scanner kb= new Scanner(System.in);
        value=kb.nextInt();
        pw.println(value);
    }
    /**
     * Converts decimal number to binary number using a tradition remainder devision method.
     */
    private void toBin(){
        while(value>0){
            numStrg =(value%2)+numStrg;
            value= value/2;
        }
    }
    /**
     * Outputs binary number into a 32 bit format of 8 nibbles.
     */
    private void outBin(){
        /*
         * Adds 0's to front of binaray number to make 32 bits.
        */
        int append=32-numStrg.length();
        while(append>0){
            numStrg="0"+numStrg;
            append--;
        }
        /*
         * Takes numString and formats it to nibble format.
        */
        String nibbleFormat="";
        for(int i=0; i<31;){
            nibbleFormat+=numStrg.substring(i, i+4)+" ";
            i=i+4;
        }
        //Prints/Echos
        System.out.println("--> "+ nibbleFormat);
        pw.println("--> "+ nibbleFormat);
    }
    /**
     * Maps input value to hex equivalent using switch. 
     */
    private void toHex(){
        while(value>0){
        switch (value%16) {
            //concatinates each mapped convertion to numStrg
            case 0 :numStrg=0 + numStrg ; break;
            case 1 :numStrg=1 + numStrg ; break;
            case 2 :numStrg=2 + numStrg ; break;
            case 3 :numStrg=3 + numStrg ; break;
            case 4 :numStrg=4 + numStrg ; break;
            case 5 :numStrg=5 + numStrg ; break;
            case 6 :numStrg=6 + numStrg ; break;
            case 7 :numStrg=7 + numStrg ; break;
            case 8 :numStrg=8 + numStrg ; break;
            case 9 :numStrg=9 + numStrg ; break;
            case 10:numStrg='A'+numStrg ; break;
            case 11:numStrg='B'+numStrg ; break;
            case 12:numStrg='C'+numStrg ; break;
            case 13:numStrg='D'+numStrg ; break;
            case 14:numStrg='E'+numStrg ; break;
            case 15:numStrg='F'+numStrg ; break;
            }
        value= value/16;
        }
        
    }
    /**
     * Prints/Echos Hex output with leading zeros taken away.
     */
    private void outHex(){
        while(numStrg.startsWith("0")){
            numStrg=numStrg.substring(1);
        }
        System.out.println("--> 0x"+ numStrg);
        pw.println("--> 0x"+ numStrg);
    }
}

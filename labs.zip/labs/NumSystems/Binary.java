
package reviewlab;
import java.io.*;
import java.util.Scanner;
/**
 * Converts, Formats, and Prints the conversion of a Binary number to either a Decimal or Hexadecimal number.
 * @author Prescott Rowe 008771839
 */
public class Binary {
    final private PrintWriter pw;
    private String hexNum;//holds hex conversion value
    private String value;//holds user input
    private int decNum, length;//decNum holds decimal conversion value
    /**
     * 
     * @param pw is a PrintWriter object used to create an output file stream to csis.txt
     */
    public Binary(PrintWriter pw) {
        this.pw = pw;
    }
    /**
     * Invokes all off the methods to do a binary to decimal conversion.
     * Instantiates/clears decNum to an empty value.
     */
    public void binToDec(){
        decNum=0;
        inputBin();
        toDec();
        outDec();
    }
    /**
     * Invokes all off the methods to do a binary to Hexadecimal  conversion.
     * Instantiates/clears hexNum to an empty value.
     */
    public void binToHex(){
        hexNum="";
        inputBin();
        toHex();
        outHex();
    }
    /**
     * Prints/echos user's option and ask for the user to input a binary number to be converted.
     * Then saves and prints/echos input.
     * 
     */
    private void inputBin(){
        System.out.print("Enter the Binary number to be converted: ");
        pw.print("\nEnter the Binary number to be converted: ");
        Scanner kb= new Scanner(System.in);
        value=kb.nextLine();//hold user input as value
        pw.println(value);
    }
    /**
     * Converts a binary number to a decimal number using a loop to grab new last bit of string and then parsing-multiplying
     * it to a integer called decNum.
     */
    private void toDec(){
        int bit;
        length=value.length();
        for(int i=0, j=length; i<length; i++, j--){
            bit=Integer.parseInt(value.substring(j-1,j));
            decNum+=bit*(Math.pow(2, i));
        }    
        
    }
    /**
     * Prints/Echos output of the converted Decimal number.
     */
    private void outDec(){
        System.out.println("--> "+decNum);
        pw.println("--> "+decNum);
    }
    /**
     * Maps binary number to hex equivalent using a switch statement.
     */
    private void toHex(){
        /*
         *Saves last 4 characters of the string 'value' to string 'nibble'. Then maps and saves conversion value to hexNum.
        */
        String nibble;
        length=value.length();
        for(int j=length; j>0;){
            nibble=value.substring(j-4,j);
            switch (nibble) {
                case "0000" :hexNum='0'+hexNum ; break;
                case "0001" :hexNum='1'+hexNum ; break;
                case "0010" :hexNum='2'+hexNum ; break;
                case "0011" :hexNum='3'+hexNum ; break;
                case "0100" :hexNum='4'+hexNum ; break;
                case "0101" :hexNum='5'+hexNum ; break;
                case "0110" :hexNum='6'+hexNum ; break;
                case "0111" :hexNum='7'+hexNum ; break;
                case "1000" :hexNum='8'+hexNum ; break;
                case "1001" :hexNum='9'+hexNum ; break;
                case "1010" :hexNum='A'+hexNum ; break;
                case "1011" :hexNum='B'+hexNum ; break;
                case "1100" :hexNum='C'+hexNum ; break;
                case "1101" :hexNum='D'+hexNum ; break;
                case "1110" :hexNum='E'+hexNum ; break;
                case "1111" :hexNum='F'+hexNum ; break;
            }
            j-=4;
        }
    }
    /**
     * Prints/Echos Hex output with leading zeros taken away.
     */
    private void outHex(){
        while(hexNum.startsWith("0")){
            hexNum=hexNum.substring(1);
        }
        System.out.println("--> 0x"+hexNum);
        pw.println("--> 0x"+hexNum);
    }    
}

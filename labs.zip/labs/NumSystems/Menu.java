
package reviewlab;
import java.io.*;
import java.util.Scanner;
/**
 * Prints a menu and returns the users choice of conversion.
 * @author Prescott Rowe 008771839
 */
public class Menu {
    final private PrintWriter pw;
    private int choice;
    /**
     * 
     * /**@param pw is a PrintWriter object used to create an output file stream to csis.txt
     */
    public Menu(PrintWriter pw) {
        this.pw = pw;
    }
    /**
     * Prints/echos the start menu.
     */
    public void display(){
        System.out.println("\nCONVERSION CALCULATOR:\n"
                + "1) Decimal ------>   Binary\n"
                + "2) Decimal ------>   Hexadecimal\n"
                + "3) Binary  ------>   Decimal\n"
                + "4) Binary  ------>   Hexadecimal\n"
                + "5) Hexadecimal -->   Decimal\n"
                + "6) Hexadecimal -->   Binary\n"
                + "7) TERMINATE\n");
        System.out.print("Enter the coresponding number to the data type conversion wanted: ");
        pw.println("\nCONVERSION CALCULATOR:\n"
                + "1) Decimal ------>   Binary\n"
                + "2) Decimal ------>   Hexadecimal\n"
                + "3) Binary  ------>   Decimal\n"
                + "4) Binary  ------>   Hexadecimal\n"
                + "5) Hexadecimal -->   Decimal\n"
                + "6) Hexadecimal -->   Binary\n"
                + "7) TERMINATE\n");
        pw.print("Enter the coresponding number to the data type conversion wanted: ");
    }
    /**
     * getSelection: Stores user input for menu display() option
     * @return the user choice for the menu selection
     */
    public int getSelection(){
        Scanner kb= new Scanner(System.in);
        choice=kb.nextInt();
        pw.print(choice);
        return choice;
    }
}

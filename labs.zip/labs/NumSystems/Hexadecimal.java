
package reviewlab;
import java.io.*;
import java.util.Scanner;
/**
 * Converts, Formats, and Prints the conversion of a Hexadecimal number to either a Binary or Decimal number.
 * @author Prescott Rowe 008771839
 */
public class Hexadecimal {
    final private PrintWriter pw;
    private String value;
    private String binNum;
    private int decNum;
    /**
     * 
     * @param pw is a PrintWriter object used to create an output file stream to csis.txt
     */
    public Hexadecimal(PrintWriter pw) {
        this.pw = pw;
    }
    /**
     * Invokes all off the methods to do a hexadecimal to decimal  conversion.
     * Instantiates/clears decNum to an empty value.
     */
    public void hexToDec(){
        decNum=0;
        inputHex();
        toDec();
        outDec();
    }
    /**
     * Invokes all off the methods to do a hexadecimal to binary  conversion.
     * Instantiates/clears binNum to an empty value.
     */
    public void hexToBin(){
        binNum="";
        inputHex();
        toBin();
        outBin();
    }
    /**
     * Prints/echos user's option and ask for the user to input a hexadecimal number to be converted. Then saves and prints/echos input.
     * 
     */
    private void inputHex(){
        System.out.print("Enter the Hexadecimal number to be converted: ");
        pw.print("\nEnter the Hexadecimal number to be converted: ");
        Scanner kb= new Scanner(System.in);
        value=kb.nextLine();
        pw.print(value);
    }
    /**
     * Grabs last hex value in string 'value' then maps,adds,saves to decNum integer.
     */
    private void toDec(){
        int length;
        String bit;
        length=value.length();
        value=value.toUpperCase();
        for(int i=0, j=length; j>0; j--, i++){
            bit=value.substring(j-1,j);
            switch (bit) {
                case"0" :decNum= 0  + decNum ; break;
                case"1" :decNum= 1  + decNum ; break;
                case"2" :decNum= 2  + decNum ; break;
                case"3" :decNum= 3  + decNum ; break;
                case"4" :decNum= 4  + decNum ; break;
                case"5" :decNum= 5  + decNum ; break;
                case"6" :decNum= 6  + decNum ; break;
                case"7" :decNum= 7  + decNum ; break;
                case"8" :decNum= 8  + decNum ; break;
                case"9" :decNum= 9  + decNum ; break;
                case"A" :decNum= 10 + decNum ; break;
                case"B" :decNum= 11 + decNum ; break;
                case"C" :decNum= 12 + decNum ; break;
                case"D" :decNum= 13 + decNum ; break;
                case"E" :decNum= 14 + decNum ; break;
                case"F" :decNum= 15 + decNum ; break;
            }
        }    
    }
    /**
     * Prints/Echos output of the converted Decimal number.
     */
    private void outDec(){
        System.out.println("--> "+decNum);
        pw.println("\n--> "+decNum);
    }
    private void toBin(){
        int length;
        String nibble;
        length=value.length();
        value=value.toUpperCase();
        for(int i=0, j=length; j>0; j--, i++){
            nibble=value.substring(j-1,j);
            switch (nibble) {
                case"0" :binNum= "0000"  + binNum ; break;
                case"1" :binNum= "0001"  + binNum ; break;
                case"2" :binNum= "0010"  + binNum ; break;
                case"3" :binNum= "0011"  + binNum ; break;
                case"4" :binNum= "0100"  + binNum ; break;
                case"5" :binNum= "0101"  + binNum ; break;
                case"6" :binNum= "0110"  + binNum ; break;
                case"7" :binNum= "0111"  + binNum ; break;
                case"8" :binNum= "1000"  + binNum ; break;
                case"9" :binNum= "1001"  + binNum ; break;
                case"A" :binNum= "1010"  + binNum ; break;
                case"B" :binNum= "1011"  + binNum ; break;
                case"C" :binNum= "1100"  + binNum ; break;
                case"D" :binNum= "1101"  + binNum ; break;
                case"E" :binNum= "1110"  + binNum ; break;
                case"F" :binNum= "1111"  + binNum ; break;
            }
        }    
    }
    /**
     * Outputs binary number into a 32 bit format of 8 nibbles.
     */
    private void outBin(){
        /*
        * Adds 0's to front of binaray number to make 32 bits.
        */
        int append=32-binNum.length();
        while(append>0){
            binNum="0"+binNum;
            append--;
        }
        /*
         * Takes binNum and formats it to nibble format.
        */
        String nibbleFormat="";
        for(int i=0; i<31;){
            nibbleFormat+=binNum.substring(i, i+4)+" ";
            i=i+4;
        }
        /*
         *Prints/Echos formated number.
        */
        System.out.println("--> "+nibbleFormat);
        pw.println("\n--> "+nibbleFormat);
    }
}

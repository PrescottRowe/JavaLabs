
package reviewlab;
//Build: JDK: 8, Compiler: gcc, System: Linux kernel 3.16.0-38, debian based.
import java.io.*;

/**
 * Used to invoke menu class and only stop the program when '7' is entered at the menu selection screen.
 * @author Prescott Rowe 008771839
 * 
 */
public class Driver {

    /**
     * Passes print writer object to child classes and invokes the menu class
     * @param args the command line arguments 
     * @throws java.io.IOException 
     */
    public static void main(String[] args) throws IOException {
        int choice;//holds user selection
        PrintWriter pw = new PrintWriter(new FileWriter("csis.txt"));
        Decimal dec = new Decimal(pw);
        Binary bin = new Binary(pw);
        Hexadecimal hex = new Hexadecimal(pw);
        Menu menu = new Menu(pw);
        do{
            menu.display();
            choice = menu.getSelection();
            switch (choice) {
                case 1 : dec.decToBin(); break;
                case 2 : dec.decToHex(); break;
                case 3 : bin.binToDec(); break;
                case 4 : bin.binToHex(); break;
                case 5 : hex.hexToDec(); break;
                case 6 : hex.hexToBin(); break;
            }
        }while (choice != 7);
        pw.close();
    }
    
}

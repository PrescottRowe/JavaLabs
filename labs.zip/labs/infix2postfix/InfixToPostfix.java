
package stacklab;

/**
 * Converts an Infix expression to a Postfix expression
 * @author Prescott Rowe 008771839
 */
public class InfixToPostfix {
    String infix, postfix;
    SuperOutput so;
    EvalPostfix eval;
    ObjectStack s=new ObjectStack();
    
    /**
     * Constructor for output Stream to csis.txt
     * @param so 
     */
    public InfixToPostfix(SuperOutput so){
        this.so=so;
        eval=new EvalPostfix(so);
    }
    /**
     * References Priority method to convert infix to postfix.
     * Uses an Integer stack to organize conversion.
     * Ends with call to outPost().
     * @param infix 
     */
    public void setPost(String infix){
        postfix="";
        //Go through string grabing one char at a time
        for(int i=0; i<infix.length(); i++){
            Character c=infix.charAt(i);  //wrapping char into Character
            if(c!=' '){
                //if digit append to string
                if(Character.isDigit(c)){
                    postfix=postfix+c;
                }
                //uses parens to control theoretical top
                else if((char)c=='(' || priority((char)c) > priority((char)s.top())){
                    s.push(c);
                }
                else if((char)c==')'){
                    while((char)s.top()!='('){
                        postfix=postfix+s.pop();
                    }
                    s.pop();
                }
                else{//check operand priority and pop/push accordingly
                    while(priority((char)s.top()) >= priority((char)c))
                        postfix= postfix+s.pop();
                    s.push(c);
                } 
            }            
        }
        outPost();//print result
    }
    /**
     * Outputs the Postfix expression to screen and infix.txt by calling SuperOutput.java.
     */
    public void outPost(){
        so.output(("Postfix: "+postfix+"\n"));
        eval.findProduct(postfix);
    }
    /**
     * Takes an operator character and returns its PEMDOS priority.
     * @param op
     * @return int 0-3
     */
    public int priority(char op){
        switch(op){
            case'^': return 3;
            case'*':
            case'/': return 2;
            case'+':
            case'-': return 1;
            default: return 0;//used for parens
        }
    }
}

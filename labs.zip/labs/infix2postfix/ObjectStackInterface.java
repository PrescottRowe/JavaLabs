
package stacklab;

/**
 * LIFO Object Stack
 * @author Prescott Rowe 008771839
 */
public interface ObjectStackInterface {
    /**
     * Checks if stack is empty.
     * @return boolean
     */
    public boolean isEmpty();
    /**
     * Checks if stack is full.
     * @return boolean
     */
    public boolean isFull();
    /**
     * Resets the variable "top" to theoretically clear the stack.
     */
    public void clear();
    /**
     * Will take an object to be put on top of the LIFO stack
     * @param o 
     */
    public void push(Object o);
    /**
     * Will take Object off top of stack and return it.
     * @return Object
     */
    public Object pop();
    /**
     * Tracks top of stack and returns a copy of the Object value.
     * @return Object value
     */
    public Object top();
}


package stacklab;
/**
 * Formats input for ease of use.
 * @author Prescott Rowe 008771839
 */
public class Format {
    private String infix;
    SuperOutput so;
    InfixToPostfix convert;
    
    /**
     * Constructor for output to csis.txt using SuperOutput.java
     * @param so 
     */
    public Format(SuperOutput so){
        this.so=so;
        convert=new InfixToPostfix(so);
    }
    /**
     * Gets/Formats String buf.
     * @param buf
     */
    public void format(String buf){
        so.output("Infix: "+buf+"\n");
        infix='('+buf+')';//Parens are used to help stack computation.
        convert.setPost(infix);           
    }
}

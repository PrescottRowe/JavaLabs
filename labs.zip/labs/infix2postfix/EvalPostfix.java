
package stacklab;
/**
 * Takes a postfix expression, evaluates it, then prints to file and screen.
 * @author Prescott Rowe 008771839
 */
public class EvalPostfix {
    //VARIABLES AND OBJECTS USED
    int num1, num2;
    SuperOutput so;
    ObjectStack s=new ObjectStack();
    /**
     * Constructor for output Stream to csis.txt
     * @param so
     */
    public EvalPostfix(SuperOutput so){
        this.so=so;   
    }
    /**
     * Utilizes the Integer Stack to find the product of a postfix expression. 
     * Ends by calling outProduct().
     * @param postfix 
     */
    public void findProduct(String postfix){
        //for acts like heart beat
        for(int i=0; i<postfix.length(); i++){
            Character c=postfix.charAt(i);
            
            if(Character.isDigit(c)){//pushes digits to int stack
                s.push((int)Character.getNumericValue(c));
            }
            else{//Else if use operand on top two numbers then push back onto stack. 
                num2=(int)s.pop();
                num1=(int)s.pop();
                switch((char)c){
                    case'^': s.push((int)Math.pow(num1,num2)); break;
                    case'*': s.push(num1*num2); break;
                    case'/': s.push(num1/num2); break;
                    case'+': s.push(num1+num2); break;
                    case'-': s.push(num1-num2); break;
                }
            }
        }
        outProduct();//Print result
    }
    /**
     * Prints the equations product to screen and infix.txt by calling SuperOutput.java.
     */
    public void outProduct(){//Result sits on stack so must pop then print
        so.output("Product: "+(int)s.pop()+"\n\n");
    }
}

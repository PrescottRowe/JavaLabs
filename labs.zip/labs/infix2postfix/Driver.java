/**
 * Build: JDK: 8.1, Compiler: gcc, System: Linux kernel 3.16.0-38, debian based.
 */
package stacklab;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
/**
 * Starts the program method call stack and opens input file infix.txt through SuperOutput.java
 * @author Prescott Rowe 008771839
 */
public class Driver {

    /**
     * Greats user and passes file-stream String to Format.java
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException{
        //VARIABLES AND OBJECTS
        String buf;
        SuperOutput so = new SuperOutput("csis.txt");
        Format check=new Format(so);
        
        //Open infix.txt for file stream(in)
        try(Scanner fileScan = new Scanner(new File("infix.txt"))){
            so.output("INFIX-TO-POSTFIX CONVERTER AND EVALUATOR.\n");
            while(fileScan.hasNext()){
                buf=fileScan.nextLine();
                check.format(buf);//Send input string to Format.java
                
            }
            so.close();
        }      
    }
    
}

/**
 * Build: JDK: 8.1, Compiler: GCC, System: Linux kernel 3.16.0-38, debian based.
 * March 18, 2016
 */
package queueslab;

import java.io.IOException;

/**
 * To be used as an object for storing a PID and its properties. 
 * @author Prescott Rowe 008771839
 */
public final class Job{
    int inTime;
    int pid;
    int qTime;
    int level;
    int responseTime;
    int insertTime;
    int waitingTime;
    /**
     * Constructor depends on a String array input to set Job values.
     * @param buf
     * @throws java.io.IOException
     */
    public Job(String[] buf) throws IOException{
        inTime=Integer.parseInt(buf[0]);
        pid=Integer.parseInt(buf[1]);
        qTime=Integer.parseInt(buf[2]);
        level=1;
        responseTime=0;
        insertTime=0;
        waitingTime=0;
    }    
    
}

/**
 * Build: JDK: 8.1, Compiler: GCC, System: Linux kernel 3.16.0-38, debian based.
 * March 18, 2016
 */
package queueslab;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;
/**
 * Simulates a simplified version of the multi user core of many older OS's like that of the Berkly SVR *nix kernels. 
 *  
 * @author Prescott Rowe 008771839
 */
public class Driver {

    /**
     * Acts as main backbone of program. Imports from input file and uses while loop to run program until
     * input file, queues, and cpu are all empty. Then it runs a final print before shutdown.
     * @author Prescott Rowe 008771839
     * @param args the command line arguments
     * @throws java.io.IOException
     * 
     */
    public static void main(String[] args)throws IOException{
        //OBJECTS
        MFQ mfq=new MFQ();
        ObjectQueue jobsQ=new ObjectQueue();
        String[] buf;
        Job inJob;     
         //FILE INPUT
        //
        try(Scanner fileScan = new Scanner(new File("mfq.txt"))){ 
            while(fileScan.hasNext()){//Enters every line of file into a JobQueue before exicution of System time.
                String delims="[ ]+";
                String holdLine=fileScan.nextLine();
                buf=holdLine.split(delims);  
                Job job=new Job(buf);
                jobsQ.insert(job);
                mfq.setJobCount();
            }
        }          
        mfq.format();//CREATES OUTPUT TABLE
        inJob=(Job)jobsQ.remove();//grabs first object to use for while loop comparison
        
        while(mfq.getCpuFlag()||mfq.getQuesFlag()||!jobsQ.isEmpty()){//while everything NOT empty
            ++mfq.clock;//sys clock
            if(mfq.getCpuFlag()){//if cpu full
                mfq.quantumClock(mfq.clock);
                mfq.checkStatus();
            }
            else{
                mfq.setIdleTime();//for totals
            }
            if(inJob.inTime==mfq.clock){//check entry time on job-O and insert/process if same as sys clock
                mfq.printIn(inJob, mfq.clock);
                mfq.que1(inJob);//send to be processed
                if(!jobsQ.isEmpty()){
                    inJob=(Job)jobsQ.remove();//get next job object to wait at door
                }
            }  
        }
        mfq.printStats();//prints totals
        System.exit(0);//EXIT
    }
}
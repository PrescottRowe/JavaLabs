/**
 * Build: JDK: 8.1, Compiler: GCC, System: Linux kernel 3.16.0-38, debian based.
 * March 18, 2016
 */
package queueslab;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

/**
 * Prints working output while also tracking various totals and averages for a final output.
 * @author Prescott Rowe 008771839
 */
public class Results{
    private int jobCount, jobsTime, responseTimeAvg, totalWaitTime, idle;
    PrintWriter pw;
    
    public Results(){
        jobCount=0;
        jobsTime=0;
        responseTimeAvg=0;
        totalWaitTime=0;
        idle=0;
    }
    /**
     * Creates a spreadsheet styled table for organized output.
     * @throws java.io.IOException
     */
    public void format() throws IOException{
        this.pw = new PrintWriter(new FileWriter("csis.txt"));
        System.out.println("     \t\t"+"       \t\t"+"   \t\t"+"CPU \t\t"+"TOTAL  \t\t"+"LOWEST");
        System.out.println("     \t\t"+"SYSTEM \t\t"+"   \t\t"+"TIME\t\t"+"TIME IN\t\t"+"LEVEL ");
        System.out.println("EVENT\t\t"+"TIME   \t\t"+"PID\t\t"+"REQ.\t\t"+"SYSTEM \t\t"+"QUEUE \n");
        pw.println("     \t\t"+"       \t\t"+"   \t\t"+"CPU \t\t"+"TOTAL  \t\t"+"LOWEST");
        pw.println("     \t\t"+"SYSTEM \t\t"+"   \t\t"+"TIME\t\t"+"TIME IN\t\t"+"LEVEL ");
        pw.println("EVENT\t\t"+"TIME   \t\t"+"PID\t\t"+"REQ.\t\t"+"SYSTEM \t\t"+"QUEUE \n");
    }
    /**
     * Prints Job stats as it enters the system queues.
     * @param job
     * @param systime
     */
    public void printIn(Job job, int systime){  
        System.out.println("Arival    \t"+systime+"\t\t"+job.pid+"\t\t"+job.qTime);
        pw.println("Arival    \t"+systime+"\t\t"+job.pid+"\t\t"+job.qTime);
    }
    /**
     * Prints Job stats after finishing execution by cpu.
     * @param job
     * @param sysTime
     */
    public void printOut(Job job, int sysTime){
        setJobsRuntime(sysTime-job.inTime);
        setResponseTimeAvg(job);
        setTotalWaitTime(job);
        System.out.println("Departure \t"+sysTime+"\t\t"+job.pid+"\t\t\t\t"+(sysTime-job.inTime)+"\t\t"+job.level);
        pw.println("Departure \t"+sysTime+"\t\t"+job.pid+"\t\t\t\t"+(sysTime-job.inTime)+"\t\t"+job.level);
    }
    /**
     * Prints out final totals and averages carried through runtime.
     */
    public void printStats(){
        System.out.println("\n\t\t\t*SYSTEM AVERAGES AND TOTALS*");
        System.out.println("Job count: "+getJobCount());
        System.out.println("Runtime of all jobs: "+getJobsRuntime());
        System.out.format("Average response time of jobs: %4.2f\n",getResponseTime());
        System.out.format("Average Job time turnaround: %4.2f\n",getTurnAroundTime());
        System.out.format("Average Wait time: %4.2f\n",getAvgWaitTime());
        System.out.format("Average System thoughtput: %4.2f\n",getTroughPut());
        System.out.println("CPU Idle time: "+getIdleTime());
        pw.println("\n\t\t\t*SYSTEM AVERAGES AND TOTALS*");
        pw.println("Job count: "+getJobCount());
        pw.println("Runtime of all jobs: "+getJobsRuntime());
        pw.format("Average response time of jobs: %4.2f\n",getResponseTime());
        pw.format("Average Job time turnaround: %4.2f\n",getTurnAroundTime());
        pw.format("Average Wait time: %4.2f\n",getAvgWaitTime());
        pw.format("Average System thoughtput: %4.2f\n",getTroughPut());
        pw.println("CPU Idle time: "+getIdleTime());
        pw.close();
    }
    /**
     * Mutator: Counts Jobs in system.
     */
    public void setJobCount(){
        jobCount++;
    }
    /**
     * Mutator: Sum of total runtime by jobs.
     * @param time
     */
    public void setJobsRuntime(int time){
        jobsTime+=time;
    }
    /**
     * Mutator: Tracks average time it takes for a job to enter system.
     * @param job
     */
    public void setResponseTimeAvg(Job job){
        responseTimeAvg+=job.responseTime;
    }
    /**
     * Mutator: Total of all jobs wait time.
     */
    private void setTotalWaitTime(Job job){
        totalWaitTime+=job.waitingTime;
    }
    /**
     * Mutator: Counts clock cycles that cpu is idle.
     */
    public void setIdleTime(){
        idle++;
    }
    /**
     * Accessor: Returns job count.
     */
    private int getJobCount(){
        return jobCount;
    }
    /**
     * Accessor: Returns runtime.
     */
    private int getJobsRuntime(){
        return jobsTime;
    }
    /**
     * Accessor: Returns average response time.
     */
    private float getResponseTime(){
        return (float)responseTimeAvg/jobCount;
    }
    /**
     * Accessor:Returns average turnaround time.
     */
    private float getTurnAroundTime(){
        return (float) jobsTime/jobCount;
    }
    /**
     * Accessor:Returns average wait time.
     */
    private float getAvgWaitTime(){
        return (float)totalWaitTime/jobCount;
    }
    /**
     * Accessor:Returns throughput average.
     */
    private float getTroughPut(){
        return (float)jobCount/jobsTime;
    }
    /**
     * Accessor:Returns Idle time.
     */
    private int getIdleTime(){
        return idle;
    }
}

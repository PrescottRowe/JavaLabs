/**
 * Build: JDK: 8.1, Compiler: GCC, System: Linux kernel 3.16.0-38, debian based.
 * March 18, 2016
 */
package queueslab;


/**
 * Simulates a cpu by decrementing quantum and job times as the system clock fires.
 * @author Prescott Rowe 008771839
 */
public class CPU extends Results{
    int quantumClock=0;
    boolean cpuFlag;
    Job cpuJob;
    /**
     * Takes a job as input from the MFQ and sets the quantum time and busy flag.
     * @param job
     * @param clock
     */
    public void toCPU(Job job, int clock){
        job.waitingTime+=clock-job.insertTime;//tracking for total job wait time
        cpuJob=job;
        setQuantum(cpuJob.level);//set quantum clock
        setCpuFlag(true);//set cpu flag
    }
    /**
     * Mutator: Sets quantum time.
     * @param val
     */
    public void setQuantum(int val){
        quantumClock=(int)Math.pow(2, val);    
    }
    /**
     * Decrements the quantum time and checks status of the job and the cpu quantum after.
     * @param clock
     */
    public void quantumClock(int clock){
        --quantumClock;
        cpuJob.qTime=cpuJob.qTime-1;//decriment job time
        if(cpuJob.qTime==0){//if job compleated reset cpu and print
            quantumClock=0;
            setCpuFlag(false);
            printOut(cpuJob, clock);
        }
    }
    /**
     * Mutator: sets busy flag.
     * @param flag
     */
    public void setCpuFlag(boolean flag){
        cpuFlag=flag;
    }
    /**
     * Returns true if CPU busy.
     * @return boolean
     */
    public boolean getCpuFlag(){
        return cpuFlag;
    }
}

/**
 * Build: JDK: 8.1, Compiler: GCC, System: Linux kernel 3.16.0-38, debian based.
 * March 18, 2016
 */
package queueslab;

/**
 * FIFO Object Queue
 * @author Prescott Rowe 008771839
 */
public interface ObjectQueueInterface {
    /**
     * Returns true if Queue is Empty.
     * @return boolean
     */
    public boolean isEmpty();
    /**
     * Returns true if Queue is full. Mainly used internally by Queue class.
     * @return boolean
     */
    public boolean isFull();
    /**
     * Resets a Queue to be empty.
     */
    public void clear();
     /**
     * Used to insert an object into rear of Queue.
     * @param o
     */
    public void insert(Object o);
    /**
     * Used to Return the object at the front of the queue.
     * @return o (Object)
     */
    public Object remove();
    /**
     * Returns the object value at front of queue without removing the object from the queue.
     * @return o (Object)
     */
    public Object query();
}

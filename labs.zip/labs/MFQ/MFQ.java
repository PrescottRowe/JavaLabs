/**
 * Build: JDK: 8.1, Compiler: GCC, System: Linux kernel 3.16.0-38, debian based.
 * March 18, 2016
 */
package queueslab;


/**
 * Holds and organizes 4 Object Queues and there processing..
 * @author Prescott Rowe 008771839
 */
public class MFQ extends CPU{
    int clock=0;
    ObjectQueue que1=new ObjectQueue();
    ObjectQueue que2=new ObjectQueue();
    ObjectQueue que3=new ObjectQueue();
    ObjectQueue que4=new ObjectQueue();
    Job jobRemoved;
    /**
     * Checks CPU busy flag and inserts job by priority if CPU free.
     */
    public void process(){
        if(!getCpuFlag()){//if cpu not busy
            //Push a job to the cpu in priority of if statement 
            if(!que1.isEmpty()){
                jobRemoved=(Job)que1.remove();
                jobRemoved.responseTime=clock-jobRemoved.inTime;
                toCPU(jobRemoved, clock);
            }
            else if(!que2.isEmpty()){
                toCPU((Job)que2.remove(), clock);
            } 
            else if(!que3.isEmpty()){
                toCPU((Job)que3.remove(), clock);
            } 
            else if(!que4.isEmpty()){
                toCPU((Job)que4.remove(), clock);
            }
        }    
    }
    /**
     * Takes job Object to insert into que1.
     * @param job
     */
    public void que1(Job job){
        job.insertTime=clock;
        que1.insert(job);
        process();
    }
    /**
     * Takes job Object to insert into que2.
     * @param job
     */
    public void que2(Job job){
        job.insertTime=clock;
        que2.insert(job);
        process();
    }
    /**
     * Takes job Object to insert into que3.
     * @param job
     */
    public void que3(Job job){
        job.insertTime=clock;
        que3.insert(job);
        process();
    }
    /**
     * Takes job Object to insert into que4.
     * @param job
     */
    public void que4(Job job){
        job.insertTime=clock;
        que4.insert(job);
        process();
    }
    /**
     * After CPU quantum decremented to 0, CheckStatus will push job to appropreate queue. 
     */
    public void checkStatus(){      
        if(quantumClock==0&&cpuJob.qTime>0){//if job still needs work but quantum expired
            setCpuFlag(false);
            if(cpuJob.level<4){
                ++cpuJob.level;
            }   
            switch(cpuJob.level){//send to appropreate que
                case 2: que2(cpuJob);break;
                case 3: que3(cpuJob);break;
                case 4: que4(cpuJob);break;
            }
        }     
        if(!getCpuFlag()){//checks condition twice for change of status
            process();
        }    
    }
    /**
     * Returns true if any of the queues have a Object within them.
     * @return 
     */
    public boolean getQuesFlag(){
        return !que1.isEmpty()||!que2.isEmpty()||!que3.isEmpty()||!que4.isEmpty();
    }
}
